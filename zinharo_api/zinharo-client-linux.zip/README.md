# Zinharo Linux Client

Thank you for downloading the latest version of the Zinharo Linux Client. This program is designed to be ran on machines that don't mind 100% cpu usage due to the affects of `.cap` cracking.

## Starting

Set a username:

```bash
export ZINHARO_USERNAME=myusername
```

Set a password:

```bash
export ZINHARO_PASSWORD=mypassword
```

OPTIONAL: If you are signing up and have not already got a client instance, you can set this signup variable:

```bash
export ZINHARO_SIGNUP=true
```

You're now set, simply run `./zinharo-client` to start contributing to the Zinharo project!
